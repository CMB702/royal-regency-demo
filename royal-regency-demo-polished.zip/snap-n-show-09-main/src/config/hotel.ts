/**
 * HOTEL CONFIGURATION — single source of truth.
 * DEMO CONCEPT: values in UPPER_SNAKE_CASE are placeholders and MUST be
 * replaced with verified information before the site goes live.
 */
import hero from "@/assets/hero.jpg";
import room from "@/assets/room.jpg";
import dining from "@/assets/dining.jpg";
import events from "@/assets/events.jpg";
import lobby from "@/assets/lobby.jpg";
import hospitality from "@/assets/hospitality.jpg";

export const HOTEL_PHONE_NUMBER = "HOTEL_PHONE_NUMBER";
export const HOTEL_WHATSAPP_NUMBER = "HOTEL_WHATSAPP_NUMBER";
export const HOTEL_EMAIL = "HOTEL_EMAIL";
/** Replace with the verified Google Maps link for the Butibori property. */
export const HOTEL_GOOGLE_MAPS_URL = "";
/** Optional: verified Google Maps embed URL. Empty = general Butibori area. */
export const HOTEL_GOOGLE_MAPS_EMBED_URL = "";

const isPlaceholder = (v: string) => !v || /^HOTEL_/.test(v);

export const hotel = {
  name: "Hotel Royal Regency",
  locality: "Butibori",
  city: "Nagpur",
  state: "Maharashtra",
  country: "India",
  phone: HOTEL_PHONE_NUMBER,
  whatsapp: HOTEL_WHATSAPP_NUMBER,
  email: HOTEL_EMAIL,
  social: {
    instagram: "HOTEL_INSTAGRAM_URL",
    facebook: "HOTEL_FACEBOOK_URL",
  },
  links: {
    tel: isPlaceholder(HOTEL_PHONE_NUMBER) ? "#contact" : `tel:${HOTEL_PHONE_NUMBER}`,
    whatsapp: isPlaceholder(HOTEL_WHATSAPP_NUMBER)
      ? "#contact"
      : `https://wa.me/${HOTEL_WHATSAPP_NUMBER.replace(/\D/g, "")}`,
    email: isPlaceholder(HOTEL_EMAIL) ? "#contact" : `mailto:${HOTEL_EMAIL}`,
    directions:
      HOTEL_GOOGLE_MAPS_URL ||
      "https://www.google.com/maps/search/?api=1&query=Butibori%2C+Nagpur%2C+Maharashtra%2C+India",
    mapEmbed:
      HOTEL_GOOGLE_MAPS_EMBED_URL ||
      "https://maps.google.com/maps?q=Butibori,%20Nagpur,%20Maharashtra,%20India&z=13&output=embed",
    mapIsVerified: Boolean(HOTEL_GOOGLE_MAPS_URL),
  },
  heroImage: hero,
  /* PLACEHOLDER — verify before going live */
  about:
    "Discover a comfortable hospitality experience in Butibori, Nagpur, conveniently located for business and leisure travellers.",
  rooms: [
    { name: "Standard Room", image: room, note: "Room details available on enquiry." },
    { name: "Deluxe Room", image: lobby, note: "Room details available on enquiry." },
    { name: "Premium Room", image: hospitality, note: "Room details available on enquiry." },
  ],
  dining: {
    image: dining,
    description:
      "A refined dining experience can be presented here with the hotel's verified restaurant name, menu and timings.",
  },
  events: {
    image: events,
    types: ["Weddings", "Corporate Events", "Meetings", "Conferences", "Celebrations"],
  },
  facilities: [
    "Accommodation",
    "Dining",
    "Events",
    "Location",
    "Guest Experience",
  ],
  gallery: [
    { src: hero, label: "Exterior", alt: "Illustrative hotel exterior at dusk (demo image)" },
    { src: room, label: "Rooms", alt: "Illustrative hotel bedroom (demo image)" },
    { src: dining, label: "Restaurant", alt: "Illustrative restaurant table setting (demo image)" },
    { src: events, label: "Events", alt: "Illustrative banquet hall setup (demo image)" },
    { src: lobby, label: "Interior", alt: "Illustrative hotel lobby interior (demo image)" },
    { src: hospitality, label: "Hospitality", alt: "Illustrative front-desk welcome (demo image)" },
  ],
};
