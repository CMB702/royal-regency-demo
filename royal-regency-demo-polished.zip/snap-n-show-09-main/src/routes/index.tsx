import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import {
  Menu,
  X,
  Phone,
  MessageCircle,
  MapPin,
  Mail,
  Check,
  BedDouble,
  Utensils,
  CalendarDays,
  MapPinned,
  Sparkles,
} from "lucide-react";
import { hotel } from "@/config/hotel";

const TITLE = "Hotel Royal Regency | Butibori, Nagpur";
const DESC =
  "Hotel Royal Regency, Butibori, Nagpur — explore accommodation, dining, events and hospitality services.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const NAV = [
  ["Home", "home"],
  ["About", "about"],
  ["Rooms", "rooms"],
  ["Dining", "dining"],
  ["Events", "events"],
  ["Gallery", "gallery"],
  ["Location", "location"],
  ["Contact", "contact"],
] as const;

const btnGold =
  "inline-flex min-h-12 items-center justify-center gap-2 rounded-sm bg-gold px-7 text-sm font-semibold tracking-wide text-accent-foreground transition hover:brightness-110";
const btnOutlineLight =
  "inline-flex min-h-12 items-center justify-center gap-2 rounded-sm border border-ivory/40 px-7 text-sm font-semibold tracking-wide text-ivory transition hover:border-gold hover:text-gold";
const btnNavy =
  "inline-flex min-h-12 items-center justify-center gap-2 rounded-sm bg-primary px-7 text-sm font-semibold tracking-wide text-primary-foreground transition hover:bg-navy";
const btnOutline =
  "inline-flex min-h-12 items-center justify-center gap-2 rounded-sm border border-primary/25 px-7 text-sm font-semibold tracking-wide text-primary transition hover:border-gold hover:text-gold";

const external = { target: "_blank", rel: "noopener noreferrer" } as const;

function Index() {
  return (
    <div className="bg-background text-foreground">
      <Header />
      <main>
        <Hero />
        <About />
        <Rooms />
        <Dining />
        <Events />
        <Facilities />
        <Gallery />
        <Location />
        <Contact />
      </main>
      <Footer />
      <MobileBar />
    </div>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  const solid = scrolled || open;
  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        solid ? "bg-navy/95 shadow-lg backdrop-blur" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-4 px-5 py-4 lg:px-8">
        <a href="#home" className="min-w-0 leading-tight text-ivory">
          <span className="block truncate font-display text-2xl tracking-wide">Royal Regency</span>
          <span className="block text-[0.6rem] uppercase tracking-[0.35em] text-gold">Butibori · Nagpur</span>
        </a>
        <nav aria-label="Main" className="hidden items-center gap-7 lg:flex">
          {NAV.map(([label, id]) => (
            <a key={id} href={`#${id}`} className="text-[0.8rem] tracking-wide text-ivory/85 transition hover:text-gold">
              {label}
            </a>
          ))}
        </nav>
        <button
          className="grid h-11 w-11 shrink-0 place-items-center text-ivory lg:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav aria-label="Mobile" className="border-t border-ivory/10 bg-navy px-5 pb-6 lg:hidden">
          {NAV.map(([label, id]) => (
            <a
              key={id}
              href={`#${id}`}
              onClick={() => setOpen(false)}
              className="block border-b border-ivory/10 py-4 font-display text-2xl text-ivory"
            >
              {label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="relative flex min-h-[100svh] items-end overflow-hidden bg-navy">
      <img
        src={hotel.heroImage}
        alt="Illustrative image of an elegant hotel exterior at dusk (demo image)"
        width={1376}
        height={768}
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="hero-overlay absolute inset-0" />
      <div className="reveal relative mx-auto w-full max-w-7xl px-5 pb-28 pt-32 lg:px-8 lg:pb-24">
        <span className="mb-6 inline-block border border-gold/60 px-3 py-1 text-[0.65rem] font-semibold uppercase tracking-[0.3em] text-gold">
          Concept Preview
        </span>
        <p className="eyebrow mb-4">{hotel.name} · {hotel.locality}, {hotel.city}, {hotel.state}</p>
        <h1 className="max-w-4xl font-display text-5xl leading-[1.02] text-ivory sm:text-6xl lg:text-7xl xl:text-8xl">
          Comfort. Hospitality. Convenience.
        </h1>
        <p className="mt-6 max-w-xl text-lg text-ivory/80">
          A premium hospitality experience in Butibori, Nagpur.
        </p>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <a href="#rooms" className={btnGold}>Explore Rooms</a>
          <a href="#contact" className={btnOutlineLight}>Contact Hotel</a>
          <a href={hotel.links.directions} {...external} className={btnOutlineLight}>
            <MapPin className="h-4 w-4" /> Get Directions
          </a>
        </div>
      </div>
    </section>
  );
}

function SectionHead({ eyebrow, title, light }: { eyebrow: string; title: string; light?: boolean }) {
  return (
    <div className="mb-12">
      <p className="eyebrow mb-4">{eyebrow}</p>
      <h2 className={`font-display text-4xl leading-tight sm:text-5xl ${light ? "text-ivory" : "text-primary"}`}>{title}</h2>
      <span className="gold-rule mt-6" />
    </div>
  );
}

function About() {
  return (
    <section id="about" className="mx-auto grid max-w-7xl gap-12 px-5 py-24 lg:grid-cols-2 lg:items-center lg:px-8 lg:py-32">
      <div>
        <SectionHead eyebrow="About" title={`About ${hotel.name}`} />
        <p className="text-lg leading-relaxed text-muted-foreground">{hotel.about}</p>
        <p className="mt-6 max-w-xl text-sm italic text-muted-foreground">
          A presentation concept. The hotel's own story, verified details and photography can be added in the final version.
        </p>
      </div>
      <img
        src={hotel.gallery[4]!.src}
        alt={hotel.gallery[4]!.alt}
        loading="lazy"
        width={1280}
        height={960}
        className="aspect-[4/3] w-full rounded-sm object-cover"
      />
    </section>
  );
}

function Rooms() {
  return (
    <section id="rooms" className="bg-secondary py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHead eyebrow="Rooms & Accommodation" title="Stay in comfort" />
        <div className="grid gap-8 md:grid-cols-3">
          {hotel.rooms.map((r) => (
            <article key={r.name} className="group overflow-hidden rounded-sm bg-card shadow-sm">
              <div className="overflow-hidden">
                <img
                  src={r.image}
                  alt={`${r.name} — illustrative demo image`}
                  loading="lazy"
                  width={1280}
                  height={960}
                  className="aspect-[4/3] w-full object-cover transition duration-700 group-hover:scale-105"
                />
              </div>
              <div className="p-7">
                <h3 className="font-display text-3xl text-primary">{r.name}</h3>
                <p className="mt-2 text-xs uppercase tracking-[0.25em] text-gold">Details on Request</p>
                <p className="mt-4 text-sm text-muted-foreground">{r.note}</p>
                <a href="#contact" className={`${btnOutline} mt-6 w-full`}>Enquire Now</a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Dining() {
  return (
    <section id="dining" className="bg-navy">
      <div className="mx-auto grid max-w-7xl lg:grid-cols-2">
        <img
          src={hotel.dining.image}
          alt="Illustrative restaurant table with Indian dishes (demo image)"
          loading="lazy"
          width={1280}
          height={960}
          className="aspect-[4/3] h-full w-full object-cover"
        />
        <div className="flex flex-col justify-center px-5 py-20 lg:px-16">
          <SectionHead eyebrow="Dining" title="A table worth returning to" light />
          <p className="text-lg leading-relaxed text-ivory/75">{hotel.dining.description}</p>
          <div className="mt-10">
            <a href="#contact" className={btnGold}>Explore Dining</a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Events() {
  return (
    <section id="events" className="relative overflow-hidden py-24 lg:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[1fr_1.2fr] lg:items-center lg:px-8">
        <div>
          <SectionHead eyebrow="Banquet & Events" title="Occasions, well hosted" />
          <ul className="divide-y divide-border border-y border-border">
            {hotel.events.types.map((t) => (
              <li key={t} className="flex items-center justify-between py-4 font-display text-2xl text-primary">
                {t}
                <span className="h-1.5 w-1.5 rounded-full bg-gold" />
              </li>
            ))}
          </ul>
          <a href="#contact" className={`${btnNavy} mt-10`}>Enquire for Events</a>
        </div>
        <img
          src={hotel.events.image}
          alt="Illustrative banquet hall decorated for a celebration (demo image)"
          loading="lazy"
          width={1280}
          height={960}
          className="aspect-[4/3] w-full rounded-sm object-cover"
        />
      </div>
    </section>
  );
}

function Facilities() {
  const icons = [BedDouble, Utensils, CalendarDays, MapPinned, Sparkles];
  const descriptions = [
    "A welcoming stay can be presented with verified room information.",
    "Dining details, menu highlights and timings can be added here.",
    "A dedicated space for celebrations, meetings and events.",
    "Conveniently presented in Butibori, Nagpur.",
    "Guest-focused details can be added after confirmation.",
  ];

  return (
    <section aria-labelledby="facilities-title" className="border-y border-border bg-card py-24 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="max-w-2xl">
          <p className="eyebrow mb-4">Facilities</p>
          <h2 id="facilities-title" className="font-display text-4xl text-primary sm:text-5xl">
            Everything in one place
          </h2>
          <span className="gold-rule mt-6" />
        </div>
        <div className="mt-12 grid overflow-hidden rounded-sm border border-border sm:grid-cols-2 lg:grid-cols-5">
          {hotel.facilities.map((f, i) => {
            const Icon = icons[i];
            return (
              <div key={f} className="group border-b border-border p-7 transition hover:bg-secondary sm:odd:border-r lg:border-b-0 lg:border-r lg:last:border-r-0">
                <Icon className="h-6 w-6 text-gold transition-transform duration-300 group-hover:-translate-y-1" strokeWidth={1.5} />
                <p className="mt-6 font-semibold text-primary">{f}</p>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{descriptions[i]}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Gallery() {
  return (
    <section id="gallery" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHead eyebrow="Gallery" title="Moments & spaces" />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 md:grid-rows-2">
          {hotel.gallery.map((g, i) => (
            <figure
              key={g.label}
              className={`group relative overflow-hidden rounded-sm ${i === 0 ? "col-span-2 md:row-span-2" : ""}`}
            >
              <img
                src={g.src}
                alt={g.alt}
                loading="lazy"
                className="h-full min-h-40 w-full object-cover transition duration-700 group-hover:scale-105"
              />
              <figcaption className="absolute bottom-0 left-0 bg-navy/80 px-3 py-1.5 text-[0.65rem] uppercase tracking-[0.25em] text-ivory">
                {g.label}
              </figcaption>
            </figure>
          ))}
        </div>
        <p className="mt-6 text-xs uppercase tracking-[0.18em] text-muted-foreground">
          Concept imagery shown for design preview · Actual hotel photography can be added.
        </p>
      </div>
    </section>
  );
}

function Location() {
  return (
    <section id="location" className="bg-navy py-24 lg:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[1fr_1.4fr] lg:px-8">
        <div>
          <SectionHead eyebrow="Location" title="Find us in Butibori" light />
          <address className="not-italic font-display text-3xl leading-snug text-ivory">
            {hotel.name}<br />
            {hotel.locality}<br />
            {hotel.city}, {hotel.state}<br />
            {hotel.country}
          </address>
          {!hotel.links.mapIsVerified && (
            <p className="mt-6 text-sm leading-relaxed text-ivory/60">
              The map currently shows the general Butibori area. The exact hotel pin can be connected once the verified Google Maps listing is confirmed.
            </p>
          )}
          <a href={hotel.links.directions} {...external} className={`${btnGold} mt-10`}>
            <MapPin className="h-4 w-4" /> Get Directions
          </a>
        </div>
        <div className="overflow-hidden rounded-sm border border-gold/30">
          <iframe
            title="Map of Butibori, Nagpur"
            src={hotel.links.mapEmbed}
            loading="lazy"
            className="h-[380px] w-full lg:h-full lg:min-h-[460px]"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSent(true);
  };
  const field =
    "mt-2 w-full rounded-sm border border-input bg-card px-4 py-3 text-base outline-none transition focus:border-gold";
  const channels = [
    { icon: Phone, label: "Call the Hotel", value: "Contact details available on enquiry.", href: "#contact" },
    { icon: MessageCircle, label: "WhatsApp", value: "Contact details available on enquiry.", href: "#contact" },
    { icon: Mail, label: "Email", value: "Contact details available on enquiry.", href: "#contact" },
    { icon: MapPin, label: "Get Directions", value: `${hotel.locality}, ${hotel.city}`, href: hotel.links.directions },
  ];

  return (
    <section id="contact" className="py-24 lg:py-32">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 lg:grid-cols-2 lg:px-8">
        <div>
          <SectionHead eyebrow="Contact" title="Let's start a conversation" />
          <p className="mb-8 max-w-lg text-lg leading-relaxed text-muted-foreground">
            Room enquiries, dining, events or general questions — make it easy for guests to reach the hotel.
          </p>
          <ul className="space-y-3">
            {channels.map((c) => (
              <li key={c.label}>
                <a
                  href={c.href}
                  {...(c.href.startsWith("http") ? external : {})}
                  className="flex items-center gap-4 rounded-sm border border-border bg-card p-4 transition hover:border-gold hover:shadow-sm"
                >
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary text-gold">
                    <c.icon className="h-5 w-5" />
                  </span>
                  <span className="min-w-0">
                    <span className="block font-semibold text-primary">{c.label}</span>
                    <span className="block truncate text-sm text-muted-foreground">{c.value}</span>
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-sm border border-border bg-card p-7 shadow-sm sm:p-10">
          {sent ? (
            <div className="flex h-full flex-col items-center justify-center py-16 text-center" role="status">
              <span className="grid h-14 w-14 place-items-center rounded-full bg-gold text-accent-foreground">
                <Check />
              </span>
              <h3 className="mt-6 font-display text-3xl text-primary">Thank you for your enquiry</h3>
              <p className="mt-3 text-muted-foreground">
                This concept form is ready to be connected to the hotel's preferred enquiry channel.
              </p>
              <button onClick={() => setSent(false)} className={`${btnOutline} mt-8`}>Send another</button>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-5">
              <div>
                <h3 className="font-display text-3xl text-primary">Send an enquiry</h3>
                <p className="mt-2 text-sm text-muted-foreground">A simple enquiry flow for future guests.</p>
              </div>
              <label className="block text-sm font-medium">Name<input required name="name" className={field} /></label>
              <label className="block text-sm font-medium">Phone<input required type="tel" name="phone" className={field} /></label>
              <label className="block text-sm font-medium">Email<input type="email" name="email" className={field} /></label>
              <label className="block text-sm font-medium">Message<textarea required name="message" rows={4} className={field} /></label>
              <button type="submit" className={`${btnNavy} w-full`}>Send Enquiry</button>
              <p className="text-center text-xs text-muted-foreground">Concept preview — enquiry delivery can be connected in the final version.</p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-navy pb-28 pt-16 text-ivory/70 lg:pb-12">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 md:grid-cols-4 lg:px-8">
        <div className="md:col-span-2">
          <p className="font-display text-3xl text-ivory">{hotel.name}</p>
          <p className="mt-2 text-sm">{hotel.locality}, {hotel.city}, {hotel.state}, {hotel.country}</p>
          <a href={hotel.links.directions} {...external} className="mt-4 inline-flex items-center gap-2 text-sm text-gold">
            <MapPin className="h-4 w-4" /> Google Maps / Directions
          </a>
        </div>
        <nav aria-label="Footer" className="grid grid-cols-2 gap-2 text-sm">
          {NAV.map(([l, id]) => <a key={id} href={`#${id}`} className="hover:text-gold">{l}</a>)}
        </nav>
        <div className="space-y-2 text-sm">
          <p className="text-ivory">Contact details available on enquiry.</p>
          <p className="text-ivory/60">Phone · WhatsApp · Email</p>
        </div>
      </div>
      <div className="mx-auto mt-12 flex max-w-7xl flex-col gap-2 border-t border-ivory/10 px-5 pt-6 text-xs sm:flex-row sm:justify-between lg:px-8">
        <span className="uppercase tracking-[0.3em] text-gold">Concept Preview</span>
        <span>Presentation concept — not the official website of {hotel.name}.</span>
      </div>
    </footer>
  );
}

function MobileBar() {
  const items = [
    { icon: Phone, label: "Call", href: hotel.links.tel },
    { icon: MessageCircle, label: "WhatsApp", href: hotel.links.whatsapp },
    { icon: MapPin, label: "Directions", href: hotel.links.directions },
  ];
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-3 border-t border-gold/30 bg-navy/95 backdrop-blur lg:hidden">
      {items.map((i) => (
        <a
          key={i.label}
          href={i.href}
          {...(i.href.startsWith("http") ? external : {})}
          className="flex min-h-16 flex-col items-center justify-center gap-1 text-xs text-ivory"
        >
          <i.icon className="h-5 w-5 text-gold" />
          {i.label}
        </a>
      ))}
    </div>
  );
}
